/* X and K Enterprise — site interactions */

document.addEventListener("DOMContentLoaded", function () {
  const burger = document.querySelector(".burger");
  const navLinks = document.querySelector(".nav-links");

  if (burger && navLinks) {
    burger.addEventListener("click", function () {
      navLinks.classList.toggle("nav-open");
      burger.classList.toggle("burger-open");
    });

    // Close the mobile menu after a link is tapped
    navLinks.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navLinks.classList.remove("nav-open");
        burger.classList.remove("burger-open");
      });
    });
  }

  // Basic contact form handler (front-end only — no backend connected yet)
  const contactForm = document.querySelector(".contact form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Thanks! This is a design blueprint, so form submissions are not yet connected to email or a database.");
    });
  }
});
