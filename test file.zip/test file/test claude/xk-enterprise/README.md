# X and K Enterprise — Website Project

This folder contains the foundation build for the X and K Enterprise website, developed from the approved Website Project Proposal.

## File & Folder Structure

```
xk-enterprise/
├── index.html          Main page — semantic HTML structure (header, nav, main, footer)
├── css/
│   └── style.css        All styling — colours, typography, layout, responsive rules
├── js/
│   └── script.js         Mobile navigation toggle + contact form handling
├── assets/
│   └── images/            Placeholder folder for final photography/logo assets
└── README.md            This file
```

## HTML Structure Overview

- `<header>` — logo and primary `<nav>` (Home, About, Services, Portfolio, Process, Contact)
- `<main>` — all page content, organised into `<section>` blocks matching the proposal's sitemap:
  Hero → About → Services → Portfolio → Process → Testimonials → Contact
- `<footer>` — sitemap links, contact details, copyright

## Content & Research Sources

Copy, service packages, pricing, and structure were drawn from the approved Website Project Proposal for X and K Enterprise (Organisation Overview, Proposed Features, Design & UX, and Technical Requirements sections). Design tokens (colour palette, typography) match Section 5 of that proposal exactly:

- Colours: Navy `#1E3A5F`, Slate `#64748B`, Sky Blue `#3B82F6`, Off-white `#F8FAFC`
- Typography: Poppins (headings), Inter (body) — loaded via Google Fonts
- General web design/UX best practices referenced from Nielsen Norman Group, Web.dev, and W3C (see Proposal Section 9: References)

## Notes

- Portfolio project names, testimonials, and client names are placeholder content for demonstration and should be replaced with real case studies before launch.
- The contact form is front-end only at this stage; it is not yet connected to an email service or database.
- Images are represented with CSS gradients/placeholders pending final photography.
